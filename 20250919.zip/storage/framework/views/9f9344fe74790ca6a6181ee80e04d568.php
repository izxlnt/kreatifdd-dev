 <div class="search-popup">
        <div class="search-popup__overlay search-toggler"></div>
        <!-- /.search-popup__overlay -->
        <div class="search-popup__content">
            <form action="#">
                <label for="search" class="sr-only">search here</label><!-- /.sr-only -->
                <input type="text" id="search" placeholder="Search Here..." />
                <button type="submit" aria-label="search submit" class="thm-btn">
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>
        <!-- /.search-popup__content -->
    </div>
    <!-- /.search-popup --><?php /**PATH /home/muhammad-faiz-abdullah/Documents/Development/Kreatif/tecture-architecture-interior-laravel-template-2025-06-26-17-19-26-utc (1)/tecture-pack/tecture/resources/views/components/searchPopup.blade.php ENDPATH**/ ?>