    <div class="preloader">
        <div class="preloader__image"></div>
    </div>
    <!-- /.preloader --><?php /**PATH D:\Kaku Project\tecture\tecture-pack\Tecture\resources\views/components/preloader.blade.php ENDPATH**/ ?>