 <!--Page Header Start-->
        <section class="page-header">
            <div class="page-header__bg" style="background-image: url(<?php echo e(asset('assets/images/backgrounds/page-header-bg.jpg')); ?>);">
            </div>
            <div class="container">
                <div class="page-header__inner">
                    <div class="page-header__title-box">
                        <p>Business Models you can Consider</p>
                        <h3><?php echo e($title ?? 'Welcome'); ?></h3>
                    </div>
                    <div class="thm-breadcrumb__box">
                        <ul class="thm-breadcrumb list-unstyled">
                             <li><a href="<?php echo e(route('index')); ?>"><i class="fas fa-home"></i> Home</a></li>
                            <li><span>/</span></li>
                            <li><?php echo e($subtitle ?? 'go to home'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!--Page Header End--><?php /**PATH E:\laravel\Tecture\resources\views/components/page-header.blade.php ENDPATH**/ ?>