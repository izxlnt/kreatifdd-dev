<head>
<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $__env->yieldContent('title', 'Home One || Tecture || tecture Laravel  Template'); ?></title>
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/images/favicons/apple-touch-icon.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/images/favicons/favicon-32x32.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/images/favicons/favicon-16x16.png')); ?>" />
    <link rel="manifest" href="<?php echo e(asset('assets/images/favicons/site.webmanifest')); ?>" />
    <meta name="description" content="tecture Laravel  Template " />

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">


    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom-animate.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/swiper.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome-all.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jarallax.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.magnific-popup.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/odometer.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/nice-select.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery-ui.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/twentytwenty.css')); ?>" />


    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/slider.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/footer.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/feature.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/about.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/sliding-text.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/services.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/projects.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/design-interior.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/testimonial.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/video.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/awards.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/blog.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/brand.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/counter.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/team.css')); ?>" />

    <!-- template styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>" />

    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<?php /**PATH /home/muhammad-faiz-abdullah/Documents/Development/Kreatif/tecture-architecture-interior-laravel-template-2025-06-26-17-19-26-utc (1)/tecture-pack/kreatif_apps/resources/views/components/head.blade.php ENDPATH**/ ?>