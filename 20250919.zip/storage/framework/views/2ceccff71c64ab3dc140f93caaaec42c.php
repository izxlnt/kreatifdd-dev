<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tecture - Modern Laravel  Template</title>
    <meta name="description" content="Tecture – Modern Architecture & Interior Design Laravel  Template. This template modern and clean design with 100% responsive layout, and very easy to customize." />
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('landding_assets/images/favicons/apple-touch-icon.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('landding_assets/images/favicons/favicon-32x32.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('landding_assets/images/favicons/favicon-16x16.png')); ?>" />
    <link rel="manifest" href="<?php echo e(asset('landding_assets/images/favicons/site.webmanifest')); ?>" />

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">


    <link rel="stylesheet" href="<?php echo e(asset('landding_assets/vendors/bootstrap/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('landding_assets/vendors/fontawesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('landding_assets/vendors/animate/animate.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('landding_assets/vendors/owl-carousel/owl.carousel.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('landding_assets/vendors/icomoon-icons/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('landding_assets/css/style.css')); ?>">
</head>

<body>

    <!--Start Preloader-->
    <div class="loader js-preloader">
        <div></div>
        <div></div>
        <div></div>
    </div>
    <!--End Preloader-->


    <div class="page-wrapper">


        <!-- Hero Section Start -->
        <section class="hero-section">
            <div class="hero-section__bg"
                style="background-image: url(<?php echo e(asset('landding_assets/images/landing-page/hero-section-bg.jpg')); ?>);"></div>
            <div class="hero-section__img-one">
                <img src="<?php echo e(asset('landding_assets/images/landing-page/hero-section-img-1-1.jpg')); ?>" alt="" class="wow fadeInUp"
                    data-wow-delay="300ms">
            </div>
            <div class="hero-section__img-two">
                <img src="<?php echo e(asset('landding_assets/images/landing-page/hero-section-img-1-2.jpg')); ?>" alt="">
            </div>
            <div class="hero-section__img-three">
                <img src="<?php echo e(asset('landding_assets/images/landing-page/hero-section-img-1-3.jpg')); ?>" alt="">
            </div>
            <div class="hero-section__img-four">
                <img src="<?php echo e(asset('landding_assets/images/landing-page/hero-section-img-1-4.jpg')); ?>" alt="" class="wow fadeInRight"
                    data-wow-delay="900ms">
            </div>
            <div class="hero-section__img-five">
                <img src="<?php echo e(asset('landding_assets/images/landing-page/hero-section-img-1-5.jpg')); ?>" alt="">
            </div>

            <div class="container">
                <div class="hero-section__inner">
                    <div class="hero-section__logo">
                        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('landding_assets/images/landing-page/logo-1.png')); ?>" alt=""></a>
                    </div>
                    <div class="hero-section__content">
                        <h2 class="heor-section__title">Dedicated Template for<br> <span> Architecture & Interior
                                Design</span> </h2>
                        <ul class="list-unstyled hero-section__page-list">
                            <li>04+ Demos</li>
                            <li><span></span></li>
                            <li>20+ Inner Pages</li>
                        </ul>
                        <div class="hero-section__btns-box">
                            <div class="hero-section__btns-box-1">
                                <a href="https://themeforest.net/item/Tecture-transportation-logistics-html-template/58259405?s_rank=1"
                                    target="_blank" class="thm-btn hero-section__btn-1"><span></span>Purchase Now
                                </a>
                            </div>
                            <div class="hero-section__btns-2">
                                <a href="#view-demo" class="thm-btn hero-section__btn-2"><span></span>View Demos</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Hero Section End -->


        <!-- Demo One Start -->
        <section class="demo-one" id="view-demo">
            <div class="demo-one_shape">
                <img src="<?php echo e(asset('landding_assets/images/landing-page/shape2.png')); ?>" alt="Shape">
            </div>
            <div class="demo-one_shape1">
                <img src="<?php echo e(asset('landding_assets/images/landing-page/shape3.png')); ?>" alt="#">
            </div>
            <div class="container">
                <div class="section-title text-center">
                    <h2 class="section-title__title">Check Out Our Home pages</h2>
                    <p class="section-title__text">Welcome to the Tecture HTML Template</p>
                    <div class="round-box"></div>
                </div>
                <div class="row">
                    <!-- Demo One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="demo-one__single">
                            <div class="demo-one__image">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/demo-one-1-1.jpg')); ?>" alt="">
                                <div class="demo-one__btns">
                                    <a href="<?php echo e(route('index')); ?>" target="_blank"
                                        class="thm-btn demo-one__btn"><span></span>
                                        Multi Page
                                    </a>

                                    <a href="<?php echo e(route('index-one-page')); ?>" target="_blank"
                                        class="thm-btn demo-one__btn"><span></span>
                                        One Page
                                    </a>
                                </div>
                            </div>
                            <div class="demo-one__content">
                                <h3 class="demo-one__title">
                                    <a href="<?php echo e(route('index')); ?>" target="_blank">Home Page 01</a>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <!-- Demo One Single End -->
                    <!-- Demo One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="demo-one__single">
                            <div class="demo-one__image">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/demo-one-1-2.jpg')); ?>" alt="">
                                <div class="demo-one__btns">
                                    <a href="<?php echo e(route('index2')); ?>" target="_blank"
                                        class="thm-btn demo-one__btn"><span></span>
                                        Multi Page
                                    </a>

                                    <a href="<?php echo e(route('index2-one-page')); ?>" target="_blank"
                                        class="thm-btn demo-one__btn"><span></span>
                                        One Page
                                    </a>
                                </div>
                            </div>
                            <div class="demo-one__content">
                                <h3 class="demo-one__title">
                                    <a href="<?php echo e(route('index2')); ?>" target="_blank">Home Page 02</a>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <!-- Demo One Single End -->
                    <!-- Demo One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="demo-one__single">
                            <div class="demo-one__image">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/demo-one-1-3.jpg')); ?>" alt="">
                                <div class="demo-one__btns">
                                    <a href="<?php echo e(route('index3')); ?>" target="_blank"
                                        class="thm-btn demo-one__btn"><span></span>
                                        Multi Page
                                    </a>

                                    <a href="<?php echo e(route('index3-one-page')); ?>" target="_blank"
                                        class="thm-btn demo-one__btn"><span></span>
                                        One Page
                                    </a>
                                </div>
                            </div>
                            <div class="demo-one__content">
                                <h3 class="demo-one__title">
                                    <a href="<?php echo e(route('index3')); ?>" target="_blank">Home Page 03</a>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <!-- Demo One Single End -->
                    <!-- Demo One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="demo-one__single">
                            <div class="demo-one__image">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/demo-one-1-4.jpg')); ?>" alt="">
                                <div class="demo-one__btns">
                                    <a href="<?php echo e(route('index4')); ?>" target="_blank"
                                        class="thm-btn demo-one__btn"><span></span>Multi Page</a>
                                    <a href="<?php echo e(route('index4-one-page')); ?>" target="_blank"
                                        class="thm-btn demo-one__btn"><span></span>
                                        One Page
                                    </a>
                                </div>
                            </div>
                            <div class="demo-one__content">
                                <h3 class="demo-one__title">
                                    <a href="<?php echo e(route('index4')); ?>" target="_blank">Home Page 04</a>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <!-- Demo One Single End -->
                    <!-- Demo One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="demo-one__single">
                            <div class="demo-one__image">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/demo-one-coming-soon.jpg')); ?>" alt="Coming Soon">
                                <div class="demo-one__btns">
                                    <a href="#" target="_blank" class="thm-btn demo-one__btn"><span></span>Coming
                                        Soon</a>
                                </div>
                            </div>
                            <div class="demo-one__content">
                                <h3 class="demo-one__title">
                                    <a href="#" target="_blank">Coming Soon</a>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <!-- Demo One Single End -->
                </div>
            </div>
        </section>
        <!-- Demo One End -->



        <!-- Feature Start -->
        <section class="feature">
            <div class="feature_shape2"><img src="<?php echo e(asset('landding_assets/images/landing-page/shape5.png')); ?>" alt="#"></div>
            <div class="container">
                <div class="section-title text-center">
                    <h2 class="section-title__title">Our Core Features</h2>
                    <div class="round-box"></div>
                </div>
                <ul class="list-unstyled feature__list">

                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-1.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">4 Homepages</h4>
                        </div>
                    </li>
                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-2.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">20+ Inner Pages</h4>
                        </div>
                    </li>
                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-3.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">Fully Responsive</h4>
                        </div>
                    </li>
                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-4.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">Owl Carousel Slider</h4>
                        </div>
                    </li>
                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-5.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">Clean Coded</h4>
                        </div>
                    </li>
                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-7.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">Google Fonts</h4>
                        </div>
                    </li>

                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-10.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">404 Error Page</h4>
                        </div>
                    </li>
                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-12.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">Well Documented</h4>
                        </div>
                    </li>
                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-13.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">24/7 Support</h4>
                        </div>
                    </li>
                    <li>
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-14.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">Bootstrap 5</h4>
                        </div>
                    </li>



                    <li class="style5">
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-11.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">Dynamic Contact Form</h4>
                        </div>
                    </li>

                    <li class="style5">
                        <div class="feature__list-single">
                            <div class="feature__icon">
                                <img src="<?php echo e(asset('landding_assets/images/landing-page/feature-1-11.png')); ?>" alt="">
                            </div>
                            <h4 class="feature__title">Dynamic Newsletter Form</h4>
                        </div>
                    </li>

                </ul>
            </div>
        </section>
        <!-- Feature End -->

        <!-- Inner pages Start -->
        <section class="inner-pages">
            <div class="inner-pages__shape">
                <img src="<?php echo e(asset('landding_assets/images/landing-page/shape3.png')); ?>" alt="#">
            </div>
            <div class="container">
                <div class="section-title text-center">
                    <h2 class="section-title__title">Attractive 20+ Inner Pages</h2>
                    <div class="round-box"></div>
                </div>

                <div class="inner-pages__inner">

                    <ul class="inner-pages__filter style1 post-filter list-unstyled clearfix">
                        <li data-filter=".filter-item" class="active">
                            <p>All</p>
                        </li>
                        <li data-filter=".about">
                            <p>About</p>
                        </li>
                        <li data-filter=".services">
                            <p>Services</p>
                        </li>
                        <li data-filter=".team">
                            <p>Team</p>
                        </li>
                        <li data-filter=".blog">
                            <p>Blog</p>
                        </li>
                        <li data-filter=".pages">
                            <p>Pages</p>
                        </li>
                    </ul>

                    <div class="row filter-layout">
                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item about">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-1.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('about')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('about')); ?>">About</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item team">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-2.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('team')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('team')); ?>">Team</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item team">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-3.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('team-details')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('team-details')); ?>">Team Details</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item pages">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-4.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('testimonials')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('testimonials')); ?>">Testimonials</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item pages">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-5.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('faq')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('faq')); ?>">Faq</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item pages">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-6.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('404')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('404')); ?>">Error Page
                                        </a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item pages">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-7.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('coming-soon')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('coming-soon')); ?>">Coming Soon
                                        </a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item services">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-8.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('services')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('services')); ?>">Services
                                        </a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item services">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-9.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('evolve-space-designs')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('evolve-space-designs')); ?>">Evolve Space Designs</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item services">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-10.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('eden-home-styling')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('eden-home-styling')); ?>">Eden Home Styling
                                        </a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item services">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-11.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('harmony-interiors')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('harmony-interiors')); ?>">Harmony Interiors
                                        </a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item services">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-12.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('interior-design')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('interior-design')); ?>">
                                            Interior Design
                                        </a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item services">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-13.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('urban-design')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('urban-design')); ?>">

                                            Urban Design</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item services">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-14.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('landscape-design')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('landscape-design')); ?>">Landscape Design</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item pages">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-15.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('projects')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span> View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('projects')); ?>">Projects</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item pages">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-16.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('project-details')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('project-details')); ?>">
                                            Project Details
                                        </a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item blog">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-17.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('blog')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('blog')); ?>">
                                            Blog
                                        </a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item blog">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-18.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('blog-2')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('blog-2')); ?>">Blog standard
                                        </a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item blog">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-19.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('blog-details')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('blog-details')); ?>">Blog Details</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                        <!--Inner pages Single Start -->
                        <div class="col-xl-3 col-lg-4 col-md-6 filter-item pages">
                            <div class="inner-pages__single">
                                <div class="inner-pages__img">
                                    <div class="inner-pages__img-inner">
                                        <img src="<?php echo e(asset('landding_assets/images/landing-page/inner-pages-1-20.jpg')); ?>" alt="">

                                        <div class="btn-box">
                                            <a href="<?php echo e(route('contact')); ?>" target="_blank"
                                                class="thm-btn main-footer__btn"><span></span>View Page</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="inner-pages__single-title">
                                    <h2><a href="<?php echo e(route('contact')); ?>">

                                            Contact</a></h2>
                                </div>
                            </div>
                        </div>
                        <!--Inner pages Single End-->

                    </div>
                </div>
            </div>
        </section>
        <!-- Inner pages End -->

        <!-- Responsive Start -->
        <section class="responsive">
            <div class="container-fluid">
                <div class="section-title text-center">
                    <h2 class="section-title__title">Fully Responsive & Retina Ready</h2>
                    <p class="section-title__text">All our websites templates are responsive and retina ready and look
                        amazing on <br>all devices, browsers and screen resolutions.
                    </p>
                    <div class="round-box"></div>
                </div>
                <div class="img-box text-center">
                    <img src="<?php echo e(asset('landding_assets/images/landing-page/responsive-img.png')); ?>" alt="">
                </div>
            </div>
        </section>
        <!-- Responsive End -->

        <!-- Sliding Text Start -->
        <section class="Sliding-text">
            <div class="Sliding-text__inner clearfix marquee_mode">
                <ul class="Sliding-text__list clearfix">
                    <li><a href="#"> <span class="icon-menu"></span> Canvas Menu</a></li>
                    <li><a href="#"> <span class="icon-faq"></span> Faq</a></li>
                    <li><a href="#"> <span class="icon-dollar"></span> Pricing Table</a></li>
                    <li><a href="#"> <span class="icon-last"></span> Advance Button</a></li>
                    <li><a href="#"> <span class="icon-video-editing"></span> Background Video</a></li>
                    <li><a href="#"> <span class="icon-box"></span> Iconbox</a></li>
                    <li><a href="#"> <span class="icon-support"></span> Contact Form</a></li>
                    <li><a href="#"> <span class="icon-award"></span> Award</a></li>
                </ul>
            </div><!-- /.Sliding-text__inner -->
            <div class="Sliding-text__inner Sliding-text__inner--two clearfix marquee_mode-two">
                <ul class="Sliding-text__list clearfix">
                    <li><a href="#"> <span class="icon-facetime-button"></span> Video</a></li>
                    <li><a href="#"> <span class="icon-video-editing"></span> Portfolio</a></li>
                    <li><a href="#"> <span class="icon-header"></span> Heading</a></li>
                    <li><a href="#"> <span class="icon-slider"></span> Marque</a></li>
                    <li><a href="#"> <span class="icon-teamwork"></span> Team Member</a></li>
                    <li><a href="#"> <span class="icon-slider"></span> Carousel Slider</a></li>
                    <li><a href="#"> <span class="icon-broken-link"></span> Hover Link</a></li>
                    <li><a href="#"> <span class="icon-menu"></span> Project Slider</a></li>
                    <li><a href="#"> <span class="icon-credit-card"></span> Card</a></li>
                </ul>
            </div><!-- /.Sliding-text__inner -->
        </section>
        <!-- Sliding Text End -->


        <!-- Main Footer Start -->
        <footer class="main-footer">
            <div class="main-footer__pattern"
                style="background-image: url(<?php echo e(asset('landding_assets/images/landing-page/main-footer-pattern.png')); ?>);"></div>
            <div class="main-footer__img1"><img src="<?php echo e(asset('landding_assets/images/landing-page/main-footer-img1.png')); ?>" alt=""></div>
            <div class="main-footer__top">
                <div class="container">
                    <div class="main-footer__top-inner">
                        <h3 class="main-footer__title">Like Our Template ? Purchase now</h3>
                        <p class="main-footer__text-1">Get all demos and features with lifetime update & <br>
                            Outstanding Support</p>
                        <div class="main-footer__btn-box">
                            <a href="https://themeforest.net/item/Tecture-transportation-logistics-html-template/58259405?s_rank=1"
                                target="_blank" class="thm-btn main-footer__btn"><span></span>
                                Purchase Theme
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="main-footer__bottom">
                <div class="container">
                    <p class="main-footer__copyright">
                        © Copyright 2025 by <a href="https://themeforest.net/user/scriptfusions" target="_blank">
                            scriptfusions
                        </a> HTML Template
                    </p>
                </div>
            </div>
        </footer>
        <!-- Main Footer End -->


    </div><!-- /.page-wrapper -->

    <script src="<?php echo e(asset('landding_assets/vendors/jquery/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landding_assets/vendors/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landding_assets/vendors/wow/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('landding_assets/vendors/owl-carousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landding_assets/vendors/marquee/marquee.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landding_assets/vendors/typed-2.0.11/typed-2.0.11.js')); ?>"></script>
    <script src="<?php echo e(asset('landding_assets/vendors/appear/jquery.appear.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landding_assets/vendors/isotope/isotope.js')); ?>"></script>
    <script src="<?php echo e(asset('landding_assets/js/script.js')); ?>"></script>

</body>

</html><?php /**PATH E:\laravel\Tecture\resources\views/landding.blade.php ENDPATH**/ ?>