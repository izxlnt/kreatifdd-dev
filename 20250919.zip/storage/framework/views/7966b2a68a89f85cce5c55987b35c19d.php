        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
<?php /**PATH /home/muhammad-faiz-abdullah/Documents/Development/Kreatif/tecture-architecture-interior-laravel-template-2025-06-26-17-19-26-utc (1)/tecture-pack/tecture/resources/views/components/strickyHeaderOne.blade.php ENDPATH**/ ?>