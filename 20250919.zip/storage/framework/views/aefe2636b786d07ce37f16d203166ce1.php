<?php $__env->startSection('title', 'Error Page || tecture || tecture Laravel  Template'); ?>
<?php $__env->startPush('styles'); ?> 
    
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/contact.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/page-header.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/error-page.css')); ?>">
 
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalfda3dc930dbeed04c81809e48d7861ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.strickyHeaderTwo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('strickyHeaderTwo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $attributes = $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $component = $__componentOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Error Page','subtitle' => 'Error Page']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Error Page','subtitle' => 'Error Page']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>


        <!--Page Header End-->

        <!--Error Page Start-->
        <section class="error-page">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="container">
                <div class="error-page__inner">
                    <div class="error-page__img">
                        <img src="<?php echo e(asset('assets/images/resources/error-page-img-1.png')); ?>" alt="">
                    </div>
                    <div class="error-page__btn-box">
                        <a href="<?php echo e(route('index')); ?>" class="thm-btn error-page__btn">Back To Home <span
                                class="icon-up-right-arrow"></span> </a>
                    </div>
                </div>
            </div>
        </section>
        <!--Error Page End-->

        <!--Site Footer Start-->
        

    <?php if (isset($component)) { $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer.footerStyleOne','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer.footerStyleOne'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $attributes = $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $component = $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutCommon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/muhammad-faiz-abdullah/Documents/Development/Kreatif/tecture-architecture-interior-laravel-template-2025-06-26-17-19-26-utc (1)/tecture-pack/kreatif_apps/resources/views/pages/404.blade.php ENDPATH**/ ?>