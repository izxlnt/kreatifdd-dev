<?php $__env->startSection('title', 'Team || tecture || tecture Laravel  Template'); ?>
<?php $__env->startPush('styles'); ?> 
    
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/contact.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/page-header.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/error-page.css')); ?>">
 
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalfda3dc930dbeed04c81809e48d7861ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.strickyHeaderTwo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('strickyHeaderTwo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $attributes = $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $component = $__componentOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Expert Team','subtitle' => 'Expert Team']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Expert Team','subtitle' => 'Expert Team']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>


        <!--Page Header End-->

        <!--Team One Start -->
        <section class="team-one">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="container">
                <div class="row">
                    <!--Team One Single Start -->
                    <div class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="100ms">
                        <div class="team-one__sinlge">
                            <div class="team-one__img">
                                <img src="<?php echo e(asset('assets/images/team/team-1-1.jpg')); ?>" alt="">
                            </div>
                            <div class="team-one__content">
                                <div class="team-one__social">
                                    <a href="#"><span class="fab fa-facebook-f"></span></a>
                                    <a href="#"><span class="fab fa-vine"></span></a>
                                    <a href="#"><span class="fab fa-twitter"></span></a>
                                    <a href="#"><span class="fab fa-instagram"></span></a>
                                </div>
                                <p class="team-one__sub-title">Teka dibe bacchu</p>
                                <h3 class="team-one__title"><a href="<?php echo e(route('team-details')); ?>">Jonathan S. Wilcox</a></h3>
                            </div>
                        </div>
                    </div>
                    <!--Team One Single End -->
                    <!--Team One Single Start -->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <div class="team-one__sinlge">
                            <div class="team-one__img">
                                <img src="<?php echo e(asset('assets/images/team/team-1-2.jpg')); ?>" alt="">
                            </div>
                            <div class="team-one__content">
                                <div class="team-one__social">
                                    <a href="#"><span class="fab fa-facebook-f"></span></a>
                                    <a href="#"><span class="fab fa-vine"></span></a>
                                    <a href="#"><span class="fab fa-twitter"></span></a>
                                    <a href="#"><span class="fab fa-instagram"></span></a>
                                </div>
                                <p class="team-one__sub-title">Teka dibe bacchu</p>
                                <h3 class="team-one__title"><a href="<?php echo e(route('team-details')); ?>">Jessica Brown</a></h3>
                            </div>
                        </div>
                    </div>
                    <!--Team One Single End -->
                    <!--Team One Single Start -->
                    <div class="col-xl-4 col-lg-4 wow fadeInRight" data-wow-delay="600ms">
                        <div class="team-one__sinlge">
                            <div class="team-one__img">
                                <img src="<?php echo e(asset('assets/images/team/team-1-3.jpg')); ?>" alt="">
                            </div>
                            <div class="team-one__content">
                                <div class="team-one__social">
                                    <a href="#"><span class="fab fa-facebook-f"></span></a>
                                    <a href="#"><span class="fab fa-vine"></span></a>
                                    <a href="#"><span class="fab fa-twitter"></span></a>
                                    <a href="#"><span class="fab fa-instagram"></span></a>
                                </div>
                                <p class="team-one__sub-title">Teka dibe bacchu</p>
                                <h3 class="team-one__title"><a href="<?php echo e(route('team-details')); ?>">Jonathan Trot</a></h3>
                            </div>
                        </div>
                    </div>
                    <!--Team One Single End -->
                    <!--Team One Single Start -->
                    <div class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="900ms">
                        <div class="team-one__sinlge">
                            <div class="team-one__img">
                                <img src="<?php echo e(asset('assets/images/team/team-1-4.jpg')); ?>" alt="">
                            </div>
                            <div class="team-one__content">
                                <div class="team-one__social">
                                    <a href="#"><span class="fab fa-facebook-f"></span></a>
                                    <a href="#"><span class="fab fa-vine"></span></a>
                                    <a href="#"><span class="fab fa-twitter"></span></a>
                                    <a href="#"><span class="fab fa-instagram"></span></a>
                                </div>
                                <p class="team-one__sub-title">Teka dibe bacchu</p>
                                <h3 class="team-one__title"><a href="<?php echo e(route('team-details')); ?>">Ryan Bennet</a></h3>
                            </div>
                        </div>
                    </div>
                    <!--Team One Single End -->
                    <!--Team One Single Start -->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="1200ms">
                        <div class="team-one__sinlge">
                            <div class="team-one__img">
                                <img src="<?php echo e(asset('assets/images/team/team-1-5.jpg')); ?>" alt="">
                            </div>
                            <div class="team-one__content">
                                <div class="team-one__social">
                                    <a href="#"><span class="fab fa-facebook-f"></span></a>
                                    <a href="#"><span class="fab fa-vine"></span></a>
                                    <a href="#"><span class="fab fa-twitter"></span></a>
                                    <a href="#"><span class="fab fa-instagram"></span></a>
                                </div>
                                <p class="team-one__sub-title">Teka dibe bacchu</p>
                                <h3 class="team-one__title"><a href="<?php echo e(route('team-details')); ?>">Alister Cook</a></h3>
                            </div>
                        </div>
                    </div>
                    <!--Team One Single End -->
                    <!--Team One Single Start -->
                    <div class="col-xl-4 col-lg-4 wow fadeInRight" data-wow-delay="1500ms">
                        <div class="team-one__sinlge">
                            <div class="team-one__img">
                                <img src="<?php echo e(asset('assets/images/team/team-1-6.jpg')); ?>" alt="">
                            </div>
                            <div class="team-one__content">
                                <div class="team-one__social">
                                    <a href="#"><span class="fab fa-facebook-f"></span></a>
                                    <a href="#"><span class="fab fa-vine"></span></a>
                                    <a href="#"><span class="fab fa-twitter"></span></a>
                                    <a href="#"><span class="fab fa-instagram"></span></a>
                                </div>
                                <p class="team-one__sub-title">Teka dibe bacchu</p>
                                <h3 class="team-one__title"><a href="<?php echo e(route('team-details')); ?>">Jonathan Campbel</a></h3>
                            </div>
                        </div>
                    </div>
                    <!--Team One Single End -->
                </div>
            </div>
        </section>
        <!--Team One End -->

        <!--Brand One Start-->
        <section class="brand-one">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="container">
                <div class="brand-one__carousel owl-theme owl-carousel">
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-1.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-2.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-3.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-4.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-5.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-6.png')); ?>" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Brand One End-->

        <!--Site Footer Start-->
        

    <?php if (isset($component)) { $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer.footerStyleOne','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer.footerStyleOne'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $attributes = $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $component = $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutCommon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kaku Project\tecture\tecture-pack\Tecture\resources\views/pages/team.blade.php ENDPATH**/ ?>