<?php $__env->startSection('title', 'Projects || tecture || tecture Laravel  Template'); ?>
<?php $__env->startPush('styles'); ?> 
    
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/contact.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/page-header.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/error-page.css')); ?>">
 
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalfda3dc930dbeed04c81809e48d7861ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.strickyHeaderTwo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('strickyHeaderTwo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $attributes = $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $component = $__componentOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Projects','subtitle' => 'Projects']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Projects','subtitle' => 'Projects']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>


        <!--Page Header End-->

        <!--Projects Page Start-->
        <section class="projects-page">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="project-two__single">
                            <div class="project-two__img">
                                <img src="<?php echo e(asset('assets/images/project/projects-2-1.jpg')); ?>" alt="">
                            </div>
                            <div class="project-two__content">
                                <h3 class="project-two__title"><a href="<?php echo e(route('project-details')); ?>">Industrial Chic
                                        Restaurant</a></h3>
                                <div class="project-two__arrow">
                                    <a href="<?php echo e(asset('assets/images/project/projects-2-1.jpg')); ?>" class="img-popup"><span
                                            class="icon-up-right-arrow-1"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="project-two__single">
                            <div class="project-two__img">
                                <img src="<?php echo e(asset('assets/images/project/projects-2-2.jpg')); ?>" alt="">
                            </div>
                            <div class="project-two__content">
                                <h3 class="project-two__title"><a href="<?php echo e(route('project-details')); ?>">Amman Rotane Hotel</a>
                                </h3>
                                <div class="project-two__arrow">
                                    <a href="<?php echo e(asset('assets/images/project/projects-2-2.jpg')); ?>" class="img-popup"><span
                                            class="icon-up-right-arrow-1"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="project-two__single">
                            <div class="project-two__img">
                                <img src="<?php echo e(asset('assets/images/project/projects-2-3.jpg')); ?>" alt="">
                            </div>
                            <div class="project-two__content">
                                <h3 class="project-two__title"><a href="<?php echo e(route('project-details')); ?>">Harmony Interiors</a>
                                </h3>
                                <div class="project-two__arrow">
                                    <a href="<?php echo e(asset('assets/images/project/projects-2-3.jpg')); ?>" class="img-popup"><span
                                            class="icon-up-right-arrow-1"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="project-two__single">
                            <div class="project-two__img">
                                <img src="<?php echo e(asset('assets/images/project/projects-2-4.jpg')); ?>" alt="">
                            </div>
                            <div class="project-two__content">
                                <h3 class="project-two__title"><a href="<?php echo e(route('project-details')); ?>">Harmony Interiors</a></h3>
                                <div class="project-two__arrow">
                                    <a href="<?php echo e(asset('assets/images/project/projects-2-4.jpg')); ?>" class="img-popup"><span
                                            class="icon-up-right-arrow-1"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="project-two__single">
                            <div class="project-two__img">
                                <img src="<?php echo e(asset('assets/images/project/projects-2-5.jpg')); ?>" alt="">
                            </div>
                            <div class="project-two__content">
                                <h3 class="project-two__title"><a href="<?php echo e(route('project-details')); ?>">Amman Rotane Hotel</a>
                                </h3>
                                <div class="project-two__arrow">
                                    <a href="<?php echo e(asset('assets/images/project/projects-2-5.jpg')); ?>" class="img-popup"><span
                                            class="icon-up-right-arrow-1"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="project-two__single">
                            <div class="project-two__img">
                                <img src="<?php echo e(asset('assets/images/project/projects-2-6.jpg')); ?>" alt="">
                            </div>
                            <div class="project-two__content">
                                <h3 class="project-two__title"><a href="<?php echo e(route('project-details')); ?>">Industrial Chic
                                        Restaurant</a>
                                </h3>
                                <div class="project-two__arrow">
                                    <a href="<?php echo e(asset('assets/images/project/projects-2-6.jpg')); ?>" class="img-popup"><span
                                            class="icon-up-right-arrow-1"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Projects Page End-->

        <!--Site Footer Start-->
        

    <?php if (isset($component)) { $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer.footerStyleOne','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer.footerStyleOne'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $attributes = $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $component = $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutCommon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kaku Project\tecture\tecture-pack\Tecture\resources\views/pages/projects.blade.php ENDPATH**/ ?>