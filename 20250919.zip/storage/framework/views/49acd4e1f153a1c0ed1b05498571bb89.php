    <div class="preloader">
        <div class="preloader__image"></div>
    </div>
    <!-- /.preloader --><?php /**PATH E:\laravel\Tecture\resources\views/components/preloader.blade.php ENDPATH**/ ?>