<ul class="main-menu__list">
    <li <?php if(request()->is(['index'])): ?> class="current" <?php endif; ?>>
        <a href="<?php echo e(route('index')); ?>">Home</a>
    </li>
    <li <?php if(request()->is(['about'])): ?> class="current" <?php endif; ?>>
        <a href="<?php echo e(route('about')); ?>">About Us</a>
    </li>
    
    <li <?php if(request()->is(['contact'])): ?> class="current" <?php endif; ?>>
        <a href="<?php echo e(route('contact')); ?>">Contact</a>
    </li>
</ul>
<?php /**PATH /home/muhammad-faiz-abdullah/Documents/Development/Kreatif/tecture-architecture-interior-laravel-template-2025-06-26-17-19-26-utc (1)/tecture-pack/kreatif_apps/resources/views/components/menuList.blade.php ENDPATH**/ ?>