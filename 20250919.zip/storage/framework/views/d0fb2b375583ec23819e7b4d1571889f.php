<?php $__env->startSection('title', 'Contact || tecture || tecture Laravel  Template'); ?>
<?php $__env->startPush('styles'); ?> 
    
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/contact.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/page-header.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/error-page.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/google-map.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/united-kingdom.css')); ?>">
 
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?> 
   
<script src="<?php echo e(asset('assets/js/ajax-form.js')); ?>"></script>
 
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalfda3dc930dbeed04c81809e48d7861ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.strickyHeaderTwo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('strickyHeaderTwo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $attributes = $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $component = $__componentOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Contact','subtitle' => 'Contact']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Contact','subtitle' => 'Contact']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>

        <!--Contact Page Start-->
        <section class="contact-page">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="container">
                <div class="contact-page__inner">
                    <div class="row">
                        <div class="col-xl-5 col-lg-5">
                            <div class="contact-page__left">
                                <div class="contact-page__information">
                                    <h3 class="contact-page__information-title">Contact Informatlon</h3>
                                    <ul class="contact-page__information-list list-unstyled">
                                        <li>
                                            <div class="icon">
                                                <span class="icon-pin"></span>
                                            </div>
                                            <div class="content">
                                                <h3>Address</h3>
                                                <p>7515 Carriage Court, CA, 92236 USA</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="icon">
                                                <span class="icon-trading"></span>
                                            </div>
                                            <div class="content">
                                                <h3>Contact Namber</h3>
                                                <p><a href="tel:66561598596969">( 6656) 1598596969</a></p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="icon">
                                                <span class="icon-envelope-1"></span>
                                            </div>
                                            <div class="content">
                                                <h3>Email Us</h3>
                                                <p><a href="mailto:shifamoni6790@gmail.com">shifamoni6790@gmail.com</a>
                                                </p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>


                        <div class="col-xl-7 col-lg-7">
                            <div class="contact-page__right">
                                <h3 class="contact-page__contact-title">Get A Quote</h3>
                                <form id="contact-form" class="contact-page__form contact-form-validated"
                                    action="assets/inc/sendemail.php" method="POST">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="contact-page__input-box">
                                                <input type="text" name="name" placeholder="Your name" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contact-page__input-box">
                                                <input type="email" name="email" placeholder="Your Email" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contact-page__input-box">
                                                <input type="number" placeholder="Mobile" name="phone" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="contact-page__input-box">
                                                <input type="text" placeholder="Subject" name="subject" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="contact-page__input-box text-message-box">
                                                <textarea name="message" placeholder="Messege" required></textarea>
                                            </div>
                                            <div class="contact-page__btn-box">
                                                <button type="submit" class="thm-btn contact-page__btn"
                                                    data-loading-text="Please wait...">
                                                    Get Started
                                                    <span class="icon-up-right-arrow"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="result mt-2"></div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </section>
        <!--Contact Page End-->

        <!--Contact Info Start-->
        <section class="contact-info-section">
            <div class="container">

                <div class="row">
                    <div class="col-xl-3">
                        <div class="single-contact-info-section">
                            <div class="icon">
                                <i class=" icon-pin"></i>
                            </div>
                            <div class="single-contact-info-section__content">
                                <div class="text">
                                    <h3>Location</h3>
                                    <p>Discover innovation doorstep.</p>
                                    <p>14 Tottenham Road, United Kingdom</p>
                                </div>
                                <div class="btn-box">
                                    <a href="#">
                                        View On Map
                                        <span class="icon-up-right-arrow"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3">
                        <div class="single-contact-info-section">
                            <div class="icon">
                                <i class="icon-telephone"></i>
                            </div>
                            <div class="single-contact-info-section__content">
                                <div class="text">
                                    <h3>Telephone</h3>
                                    <p>Your bridge to hassle-free service.</p>
                                    <p><a href="tal:12122263126"> 1 212-226-3126</a></p>
                                </div>
                                <div class="btn-box">
                                    <a href="#">
                                        Get Call Back
                                        <span class="icon-up-right-arrow"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3">
                        <div class="single-contact-info-section">
                            <div class="icon">
                                <i class="icon-envelope-2"></i>
                            </div>
                            <div class="single-contact-info-section__content">
                                <div class="text">
                                    <h3>Your Email</h3>
                                    <p>Your bridge to hassle-free service.</p>
                                    <p><a href="mailto:head@transcargo.com">head@transcargo.com</a></p>
                                </div>
                                <div class="btn-box">
                                    <a href="#">
                                        Inter Email
                                        <span class="icon-up-right-arrow"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3">
                        <div class="single-contact-info-section">
                            <div class="icon">
                                <i class="far fa-clock"></i>
                            </div>
                            <div class="single-contact-info-section__content">
                                <div class="text">
                                    <h3>Off.Hrs</h3>
                                    <p>Monday-Satday: 9.00 am to 7.30 pm</p>
                                    <p>Hotline is available 24/7.</p>
                                </div>
                                <div class="btn-box">
                                    <a href="#">
                                        Get Call Back
                                        <span class="icon-up-right-arrow"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section>
        <!--Contact Info End-->

        <!--Google Map Start-->
        <section class="google-map-one">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4562.753041141002!2d-118.80123790098536!3d34.152323469614075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80e82469c2162619:0xba03efb7998eef6d!2sCostco Wholesale!5e0!3m2!1sbn!2sbd!4v1562518641290!5m2!1sbn!2sbd"
                class="google-map__one" allowfullscreen></iframe>

        </section>
        <!--Google Map End-->

        <!--Site Footer Start-->
        

    <?php if (isset($component)) { $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer.footerStyleOne','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer.footerStyleOne'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $attributes = $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $component = $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutCommon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/muhammad-faiz-abdullah/Documents/Development/Kreatif/tecture-architecture-interior-laravel-template-2025-06-26-17-19-26-utc (1)/tecture-pack/kreatif_apps/resources/views/pages/contact.blade.php ENDPATH**/ ?>