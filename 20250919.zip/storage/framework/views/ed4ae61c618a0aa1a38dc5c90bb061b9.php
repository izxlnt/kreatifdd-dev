<?php $__env->startSection('title', 'Testimonials || tecture || tecture Laravel  Template'); ?>
<?php $__env->startPush('styles'); ?> 
    
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/contact.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/page-header.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/error-page.css')); ?>">
 
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalfda3dc930dbeed04c81809e48d7861ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.strickyHeaderTwo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('strickyHeaderTwo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $attributes = $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $component = $__componentOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Testimonials','subtitle' => 'Testimonials']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Testimonials','subtitle' => 'Testimonials']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>


        <!--Page Header End-->

        <!--Testimonial Page Start-->
        <section class="testimonial-page">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="container">
                <div class="row">
                    <!-- Testimonial One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="100ms">
                        <div class="testimonial-one__single">
                            <div class="testimonial-one__client-info">
                                <div class="testimonial-one__client-img">
                                    <img src="<?php echo e(asset('assets/images/testimonial/testimonial-one-client-1-1.jpg')); ?>" alt="">
                                </div>
                                <div class="testimonial-one__client-content">
                                    <h5 class="testimonial-one__client-name"><a href="<?php echo e(route('testimonials')); ?>">Madriya
                                            Merin</a></h5>
                                    <p class="testimonial-one__client-sub-title">Spatial Design</p>
                                </div>
                            </div>
                            <p class="testimonial-one__text">Arrangements are made to transport cargo by sea
                                to meet customers’ international transpor
                                tation needs.</p>
                            <div class="testimonial-one__rating-and-review">
                                <ul class="list-unstyled testimonial-one__rating">
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-3.png')); ?>" alt="">
                                        </div>
                                    </li>
                                </ul>
                                <p class="testimonial-one__review">4.7/6 on Disign</p>
                            </div>
                        </div>
                    </div>
                    <!-- Testimonial One Single End -->
                    <!-- Testimonial One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                        <div class="testimonial-one__single">
                            <div class="testimonial-one__client-info">
                                <div class="testimonial-one__client-img">
                                    <img src="<?php echo e(asset('assets/images/testimonial/testimonial-one-client-1-2.jpg')); ?>" alt="">
                                </div>
                                <div class="testimonial-one__client-content">
                                    <h5 class="testimonial-one__client-name"><a href="<?php echo e(route('testimonials')); ?>">Mike
                                            Hardson</a></h5>
                                    <p class="testimonial-one__client-sub-title">Spatial Design</p>
                                </div>
                            </div>
                            <p class="testimonial-one__text">Arrangements are made to transport cargo by sea
                                to meet customers’ international transpor
                                tation needs.</p>
                            <div class="testimonial-one__rating-and-review">
                                <ul class="list-unstyled testimonial-one__rating">
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-3.png')); ?>" alt="">
                                        </div>
                                    </li>
                                </ul>
                                <p class="testimonial-one__review">4.7/6 on Disign</p>
                            </div>
                        </div>
                    </div>
                    <!-- Testimonial One Single End -->
                    <!-- Testimonial One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="400ms">
                        <div class="testimonial-one__single">
                            <div class="testimonial-one__client-info">
                                <div class="testimonial-one__client-img">
                                    <img src="<?php echo e(asset('assets/images/testimonial/testimonial-one-client-1-3.jpg')); ?>" alt="">
                                </div>
                                <div class="testimonial-one__client-content">
                                    <h5 class="testimonial-one__client-name"><a href="<?php echo e(route('testimonials')); ?>">Marlon
                                            Samuls</a></h5>
                                    <p class="testimonial-one__client-sub-title">Spatial Design</p>
                                </div>
                            </div>
                            <p class="testimonial-one__text">Arrangements are made to transport cargo by sea
                                to meet customers’ international transpor
                                tation needs.</p>
                            <div class="testimonial-one__rating-and-review">
                                <ul class="list-unstyled testimonial-one__rating">
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-3.png')); ?>" alt="">
                                        </div>
                                    </li>
                                </ul>
                                <p class="testimonial-one__review">4.7/6 on Disign</p>
                            </div>
                        </div>
                    </div>
                    <!-- Testimonial One Single End -->
                    <!-- Testimonial One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="600ms">
                        <div class="testimonial-one__single">
                            <div class="testimonial-one__client-info">
                                <div class="testimonial-one__client-img">
                                    <img src="<?php echo e(asset('assets/images/testimonial/testimonial-one-client-1-4.jpg')); ?>" alt="">
                                </div>
                                <div class="testimonial-one__client-content">
                                    <h5 class="testimonial-one__client-name"><a href="<?php echo e(route('testimonials')); ?>">Marco
                                            Jansen</a></h5>
                                    <p class="testimonial-one__client-sub-title">Spatial Design</p>
                                </div>
                            </div>
                            <p class="testimonial-one__text">Arrangements are made to transport cargo by sea
                                to meet customers’ international transpor
                                tation needs.</p>
                            <div class="testimonial-one__rating-and-review">
                                <ul class="list-unstyled testimonial-one__rating">
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-3.png')); ?>" alt="">
                                        </div>
                                    </li>
                                </ul>
                                <p class="testimonial-one__review">4.7/6 on Disign</p>
                            </div>
                        </div>
                    </div>
                    <!-- Testimonial One Single End -->
                    <!-- Testimonial One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="800ms">
                        <div class="testimonial-one__single">
                            <div class="testimonial-one__client-info">
                                <div class="testimonial-one__client-img">
                                    <img src="<?php echo e(asset('assets/images/testimonial/testimonial-one-client-1-5.jpg')); ?>" alt="">
                                </div>
                                <div class="testimonial-one__client-content">
                                    <h5 class="testimonial-one__client-name"><a href="<?php echo e(route('testimonials')); ?>">Mithel
                                            Mars</a></h5>
                                    <p class="testimonial-one__client-sub-title">Spatial Design</p>
                                </div>
                            </div>
                            <p class="testimonial-one__text">Arrangements are made to transport cargo by sea
                                to meet customers’ international transpor
                                tation needs.</p>
                            <div class="testimonial-one__rating-and-review">
                                <ul class="list-unstyled testimonial-one__rating">
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-3.png')); ?>" alt="">
                                        </div>
                                    </li>
                                </ul>
                                <p class="testimonial-one__review">4.7/6 on Disign</p>
                            </div>
                        </div>
                    </div>
                    <!-- Testimonial One Single End -->
                    <!-- Testimonial One Single Start -->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="1000ms">
                        <div class="testimonial-one__single">
                            <div class="testimonial-one__client-info">
                                <div class="testimonial-one__client-img">
                                    <img src="<?php echo e(asset('assets/images/testimonial/testimonial-one-client-1-6.jpg')); ?>" alt="">
                                </div>
                                <div class="testimonial-one__client-content">
                                    <h5 class="testimonial-one__client-name"><a href="<?php echo e(route('testimonials')); ?>">Alisha
                                            Martin</a></h5>
                                    <p class="testimonial-one__client-sub-title">Spatial Design</p>
                                </div>
                            </div>
                            <p class="testimonial-one__text">Arrangements are made to transport cargo by sea
                                to meet customers’ international transpor
                                tation needs.</p>
                            <div class="testimonial-one__rating-and-review">
                                <ul class="list-unstyled testimonial-one__rating">
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-2.png')); ?>" alt="">
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testimonial-one__rating-icon">
                                            <img src="<?php echo e(asset('assets/images/icon/star-icon-3.png')); ?>" alt="">
                                        </div>
                                    </li>
                                </ul>
                                <p class="testimonial-one__review">4.7/6 on Disign</p>
                            </div>
                        </div>
                    </div>
                    <!-- Testimonial One Single End -->
                </div>
            </div>
        </section>
        <!--Testimonial Page End-->

        <!--Site Footer Start-->
        

    <?php if (isset($component)) { $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer.footerStyleOne','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer.footerStyleOne'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $attributes = $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $component = $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutCommon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kaku Project\tecture\tecture-pack\Tecture\resources\views/pages/testimonials.blade.php ENDPATH**/ ?>