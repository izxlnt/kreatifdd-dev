<?php $__env->startSection('title', 'Services || tecture || tecture Laravel  Template'); ?>
<?php $__env->startPush('styles'); ?> 
    
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/contact.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/page-header.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/module-css/error-page.css')); ?>">
 
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalfda3dc930dbeed04c81809e48d7861ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.strickyHeaderTwo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('strickyHeaderTwo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $attributes = $__attributesOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__attributesOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec)): ?>
<?php $component = $__componentOriginalfda3dc930dbeed04c81809e48d7861ec; ?>
<?php unset($__componentOriginalfda3dc930dbeed04c81809e48d7861ec); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Services','subtitle' => 'Services']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Services','subtitle' => 'Services']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>


        <!--Page Header End-->

        <!-- Services One Start -->
        <section class="services-one">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="container">
                <div class="section-title text-center sec-title-animation animation-style1">
                    <h2 class="section-title__title title-animation">
                        Where Inovation Meet <br>Interior Design
                    </h2>
                </div>
                <div class="row">
                    <!-- Services One Sinlge Start -->
                    <div class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="100ms">
                        <div class="services-one__single">
                            <div class="services-one__shape-1"
                                style="background-image: url(<?php echo e(asset('assets/images/shapes/services-one-shape-1.png')); ?>);"></div>
                            <div class="services-one__content-box">
                                <h3 class="services-one__title"><a href="<?php echo e(route('evolve-space-designs')); ?>">Evolve Space
                                        Designs</a></h3>
                                <div class="services-one__img">
                                    <img src="<?php echo e(asset('assets/images/services/services-1-1.jpg')); ?>" alt="">
                                </div>
                                <p class="services-one__text">A corporate business entity is an oit organization
                                    formed with the a mans a</p>
                            </div>
                            <a href="<?php echo e(route('evolve-space-designs')); ?>" class="services-one__btn"><span
                                    class="icon-next"></span>More Details</a>
                        </div>
                    </div>
                    <!-- Services One Sinlge End -->
                    <!-- Services One Sinlge Start -->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <div class="services-one__single">
                            <div class="services-one__shape-1"
                                style="background-image: url(<?php echo e(asset('assets/images/shapes/services-one-shape-1.png')); ?>);"></div>
                            <div class="services-one__content-box">
                                <h3 class="services-one__title"><a href="<?php echo e(route('eden-home-styling')); ?>">Eden Home Styling</a>
                                </h3>
                                <div class="services-one__img">
                                    <img src="<?php echo e(asset('assets/images/services/services-1-2.jpg')); ?>" alt="">
                                </div>
                                <p class="services-one__text">A corporate business entity is an oit organization
                                    formed with the a mans a</p>
                            </div>
                            <a href="<?php echo e(route('eden-home-styling')); ?>" class="services-one__btn"><span
                                    class="icon-next"></span>More Details</a>
                        </div>
                    </div>
                    <!-- Services One Sinlge End -->
                    <!-- Services One Sinlge Start -->
                    <div class="col-xl-4 col-lg-4 wow fadeInRight" data-wow-delay="300ms">
                        <div class="services-one__single">
                            <div class="services-one__shape-1"
                                style="background-image: url(<?php echo e(asset('assets/images/shapes/services-one-shape-1.png')); ?>);"></div>
                            <div class="services-one__content-box">
                                <h3 class="services-one__title"><a href="<?php echo e(route('harmony-interiors')); ?>">Harmony Interiors</a>
                                </h3>
                                <div class="services-one__img">
                                    <img src="<?php echo e(asset('assets/images/services/services-1-3.jpg')); ?>" alt="">
                                </div>
                                <p class="services-one__text">A corporate business entity is an oit organization
                                    formed with the a mans a</p>
                            </div>
                            <a href="<?php echo e(route('harmony-interiors')); ?>" class="services-one__btn"><span
                                    class="icon-next"></span>More Details</a>
                        </div>
                    </div>
                    <!-- Services One Sinlge End -->
                </div>
            </div>
        </section>
        <!-- Services One End -->

        <!-- Sliding Text One Start -->
        <section class="sliding-text-one">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="sliding-text-one__wrap">
                <ul class="sliding-text__list list-unstyled marquee_mode">
                    <li>
                        <h2 data-hover="Interior Design" class="sliding-text__title">Interior Design
                            <img src="<?php echo e(asset('assets/images/icon/star-icon.png')); ?>" alt=""></h2>
                    </li>
                    <li>
                        <h2 data-hover="luxury homes" class="sliding-text__title">luxury homes
                            <img src="<?php echo e(asset('assets/images/icon/star-icon.png')); ?>" alt=""></h2>
                    </li>
                    <li>
                        <h2 data-hover="construction simulator" class="sliding-text__title">construction simulator
                            <img src="<?php echo e(asset('assets/images/icon/star-icon.png')); ?>" alt=""></h2>
                    </li>
                    <li>
                        <h2 data-hover="construction simulator" class="sliding-text__title">construction simulator
                            <img src="<?php echo e(asset('assets/images/icon/star-icon.png')); ?>" alt=""></h2>
                    </li>
                </ul>
            </div>
        </section>
        <!-- Sliding Text One End -->

        <!-- Awards One Start -->
        <section class="awards-one">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="container">
                <div class="section-title text-center sec-title-animation animation-style2">
                    <h2 class="section-title__title title-animation">Our Company Awards <br> & Achievements</h2>
                </div>
                <div class="row">
                    <div class="col-xl-7">
                        <div class="awards-one__left">
                            <ul class="list-unstyled awards-one__list">
                                <li class="wow fadeInLeft" data-wow-delay="100ms">
                                    <div class="awards-one__title-box">
                                        <div class="awards-one__title-circle-box">
                                            <p>W.</p>
                                        </div>
                                        <h3 class="awards-one__title">Boston Award For <br>
                                            Architecture</h3>
                                    </div>
                                    <div class="awards-one__year">
                                        <p>2024</p>
                                    </div>
                                    <div class="awards-one__arrow">
                                        <a href="<?php echo e(route('about')); ?>"><span class="icon-up-right-arrow-1"></span></a>
                                    </div>
                                </li>
                                <li class="wow fadeInLeft" data-wow-delay="200ms">
                                    <div class="awards-one__title-box">
                                        <div class="awards-one__title-circle-box">
                                            <p>W.</p>
                                        </div>
                                        <h3 class="awards-one__title">Boston Award For <br>
                                            Architecture</h3>
                                    </div>
                                    <div class="awards-one__year">
                                        <p>2025</p>
                                    </div>
                                    <div class="awards-one__arrow">
                                        <a href="<?php echo e(route('about')); ?>"><span class="icon-up-right-arrow-1"></span></a>
                                    </div>
                                </li>
                                <li class="wow fadeInLeft" data-wow-delay="400ms">
                                    <div class="awards-one__title-box">
                                        <div class="awards-one__title-circle-box">
                                            <p>W.</p>
                                        </div>
                                        <h3 class="awards-one__title">Boston Award For <br>
                                            Architecture</h3>
                                    </div>
                                    <div class="awards-one__year">
                                        <p>2026</p>
                                    </div>
                                    <div class="awards-one__arrow">
                                        <a href="<?php echo e(route('about')); ?>"><span class="icon-up-right-arrow-1"></span></a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-5">
                        <div class="awards-one__right wow slideInRight" data-wow-delay="100ms"
                            data-wow-duration="2500ms">
                            <div class="awards-one__img-box">
                                <div class="awards-one__img">
                                    <img src="<?php echo e(asset('assets/images/resources/awards-one-img-1.jpg')); ?>" alt="">
                                </div>
                                <div class="awards-one__img-two">
                                    <img src="<?php echo e(asset('assets/images/resources/awards-one-img-2.jpg')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Awards One End -->

        <!--Brand One Start-->
        <section class="brand-one">
            <div class="section-shape-1" style="background-image: url(<?php echo e(asset('assets/images/shapes/section-shape-1.png')); ?>);"></div>
            <div class="container">
                <div class="brand-one__carousel owl-theme owl-carousel">
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-1.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-2.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-3.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-4.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-5.png')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="brand-one__img">
                            <a href="#"><img src="<?php echo e(asset('assets/images/brand/brand-1-6.png')); ?>" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Brand One End-->

        <!--Site Footer Start-->
        

    <?php if (isset($component)) { $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer.footerStyleOne','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer.footerStyleOne'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $attributes = $__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__attributesOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e)): ?>
<?php $component = $__componentOriginal2dbe3a1c422efac5efef2e1846569e0e; ?>
<?php unset($__componentOriginal2dbe3a1c422efac5efef2e1846569e0e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutCommon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laravel\Tecture\resources\views/pages/services.blade.php ENDPATH**/ ?>