    <div class="preloader">
        <div class="preloader__image"></div>
    </div>
    <!-- /.preloader --><?php /**PATH /home/muhammad-faiz-abdullah/Documents/Development/Kreatif/tecture-architecture-interior-laravel-template-2025-06-26-17-19-26-utc (1)/tecture-pack/kreatif_apps/resources/views/components/preloader.blade.php ENDPATH**/ ?>