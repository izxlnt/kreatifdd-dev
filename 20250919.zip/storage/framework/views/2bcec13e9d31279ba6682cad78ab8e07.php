<script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jarallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.appear.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/swiper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.circle-progress.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/odometer.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/wNumb.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/isotope.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.circleType.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.lettering.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/marquee.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery-sidebar-content.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/twentytwenty.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.event.move.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/gsap/gsap.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/gsap/ScrollTrigger.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/gsap/SplitText.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>


<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH /home/muhammad-faiz-abdullah/Documents/Development/Kreatif/tecture-architecture-interior-laravel-template-2025-06-26-17-19-26-utc (1)/tecture-pack/tecture/resources/views/components/scripts.blade.php ENDPATH**/ ?>